function goTo(link) {
    window.location.href = link;
}
