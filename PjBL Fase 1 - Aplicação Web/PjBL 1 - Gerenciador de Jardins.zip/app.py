from controllers.app_controller import createApp


if __name__ == "__main__":
    app = createApp()
    app.run(debug=True)
